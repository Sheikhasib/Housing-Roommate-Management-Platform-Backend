import { Role } from "../../../generated/prisma/enums";
import { PaymentWhereInput } from "../../../generated/prisma/models";
import { IQuery } from "../../interfaces";
import { prisma } from "../../lib/prisma";
import { RequestUser } from "../../middleware/checkAuth";
import { AppError } from "../../utils/AppError";
import httpStatus from "http-status";

// Patient Payments
const getMyPayments = async (query: IQuery, user: RequestUser) => {
  const limit = query.limit ? Number(query.limit) : 10;
  const page = query.page ? Number(query.page) : 1;
  const skip = (page - 1) * limit;
  const sortBy = query.sortBy ? query.sortBy : "createdAt";
  const sortOrder = query.sortOrder ? query.sortOrder : "desc";

  const patient = await prisma.patient.findUnique({
    where: { userId: user.userId },
  });

  if (!patient) {
    throw new AppError(httpStatus.NOT_FOUND, "Patient Profile Not Found");
  }

  const andConditions: PaymentWhereInput[] = [
    {
      appointment: { patientId: patient.id },
    },
  ];

  const payments = await prisma.payment.findMany({
    where: { AND: andConditions },
    take: limit,
    skip,
    orderBy: { [sortBy]: sortOrder },
    include: {
      appointment: {
        include: {
          doctor: { select: { id: true, name: true, specialization: true } },
          schedule: true,
        },
      },
    },
  });

  const total = await prisma.payment.count({
    where: { AND: andConditions },
  });

  return {
    data: payments,
    meta: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    },
  };
};

// Get All Payments(Admin)
const getAllPayments = async (query: IQuery) => {
  const limit = query.limit ? Number(query.limit) : 10;
  const page = query.page ? Number(query.page) : 1;
  const skip = (page - 1) * limit;
  const sortBy = query.sortBy ? query.sortBy : "createdAt";
  const sortOrder = query.sortOrder ? query.sortOrder : "desc";

  const andConditions: PaymentWhereInput[] = [];

  // Filtering by email
  if (query.patientEmail) {
    andConditions.push({
      appointment: {
        patient: {
          email: query.email,
        },
      },
    });
  }

  const payments = await prisma.payment.findMany({
    where: { AND: andConditions },
    take: limit,
    skip,
    orderBy: { [sortBy]: sortOrder },
    include: {
      appointment: {
        include: {
          doctor: { select: { id: true, name: true, specialization: true } },
          schedule: true,
        },
      },
    },
  });

  const total = await prisma.payment.count({
    where: { AND: andConditions },
  });

  return {
    data: payments,
    meta: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    },
  };
};

// Get Single Payment by Id (Patient)
const getSinglePayment = async (paymentId: string, user: RequestUser) => {
  const payment = await prisma.payment.findUnique({
    where: { id: paymentId },
    include: {
      appointment: {
        include: {
          patient: {
            select: { id: true, name: true, email: true, userId: true },
          },
          doctor: { select: { id: true, name: true, specialization: true } },
          schedule: true,
        },
      },
    },
  });

  if (!payment) {
    throw new AppError(httpStatus.NOT_FOUND, "Payment Not Found");
  }

  // check if the user is a patient or not
  if (user.role === Role.PATIENT) {
    // check if the payment belongs to the logged in patient
    if (payment.appointment.patient.userId !== user.userId) {
      throw new AppError(
        httpStatus.FORBIDDEN,
        "You Are Not Allowed To View This Payment",
      );
    }
  }

  return payment;
};

export const PaymentServices = {
  getMyPayments,
  getAllPayments,
  getSinglePayment,
};
